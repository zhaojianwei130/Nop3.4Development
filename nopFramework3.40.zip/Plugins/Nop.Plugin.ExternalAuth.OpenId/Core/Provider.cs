

namespace Nop.Plugin.ExternalAuth.OpenId.Core
{
    public static class Provider
    {
        public static string SystemName
        {
            get
            {
                return "ExternalAuth.OpenId";
            }
        }
    }
}