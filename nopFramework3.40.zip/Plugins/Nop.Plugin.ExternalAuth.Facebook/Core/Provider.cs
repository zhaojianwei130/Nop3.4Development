
namespace Nop.Plugin.ExternalAuth.Facebook.Core
{
    public static class Provider
    {
        public static string SystemName
        {
            get
            {
                return "ExternalAuth.Facebook";
            }
        }
    }
}