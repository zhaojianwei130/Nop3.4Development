﻿
namespace Nop.Plugin.Misc.WebServices
{
    public class OrderError
    {
        public int OrderId { get; set; }
        public string ErrorMessage { get; set; }
    }
}
