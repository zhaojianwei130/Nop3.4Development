
namespace Nop.Core.Domain.Customers
{
    public static partial class SystemCustomerNames
    {
        public static string SearchEngine { get { return "SearchEngine"; } }
        public static string BackgroundTask { get { return "BackgroundTask"; } }
    }
}