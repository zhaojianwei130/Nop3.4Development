﻿
namespace Nop.Core.Configuration
{
    public interface ISettings
    {
    }
}
