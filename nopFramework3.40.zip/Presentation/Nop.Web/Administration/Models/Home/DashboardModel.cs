﻿using Nop.Web.Framework.Mvc;

namespace Nop.Admin.Models.Home
{
    public partial class DashboardModel : BaseNopModel
    {
        
    }
}